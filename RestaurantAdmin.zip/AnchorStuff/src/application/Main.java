package application;
	
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;



public class Main extends Application implements EventHandler<ActionEvent> {
	
	LinkedList<Item> menu = new LinkedList<>(); 			// Creates the linked list
	String test = String.valueOf(menu.size());
	
	
	
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		listImport( menu );
		
		primaryStage.setTitle("Restaurant App (Admin)");
		primaryStage.setMaximized(true);
		primaryStage.initStyle(StageStyle.UTILITY);
		
		AnchorPane root = new AnchorPane();
		
	
		
		// *** FOR THE MENU EDIT SIDE *** // 

		// Static Objects
		
		Rectangle meRec = new Rectangle(10, 10, 1060, 60);
		meRec.setFill(Color.rgb(0, 102, 255));
		//meRec.setFill(Color.BLUE);
		meRec.setStroke(Color.BLACK);
		
		Label menuEditLbl = new Label("Menu Edit");
		menuEditLbl.setFont(Font.font(40));
		menuEditLbl.setTextFill(Color.WHITE);
		AnchorPane.setTopAnchor(menuEditLbl, 10.0);
		AnchorPane.setLeftAnchor(menuEditLbl, 450.0);
		
		Rectangle mRec = new Rectangle(10, 215, 1060, 60);
		mRec.setFill(Color.rgb(0, 102, 255));
		mRec.setStroke(Color.BLACK);
		
		Label menuLbl = new Label("Menu");
		menuLbl.setFont(Font.font(40));
		menuLbl.setTextFill(Color.WHITE);
		AnchorPane.setTopAnchor(menuLbl, 215.0);
		AnchorPane.setLeftAnchor(menuLbl, 490.0);
		
		// Entry Box labels
		
		Label foodNameLbl = new Label("Food Name");
		AnchorPane.setTopAnchor(foodNameLbl, 80.0);
		AnchorPane.setLeftAnchor(foodNameLbl, 10.0);
		
		Label priceLbl = new Label("Price");
		AnchorPane.setTopAnchor(priceLbl, 80.0);
		AnchorPane.setLeftAnchor(priceLbl, 840.0);
		
		Label descLbl = new Label("Description");
		AnchorPane.setTopAnchor(descLbl, 140.0);
		AnchorPane.setLeftAnchor(descLbl, 10.0);
		
		
		// Create Controls
		
		TextArea itemNameFld = new TextArea();
		itemNameFld.setPrefSize(820, 30);
		AnchorPane.setTopAnchor(itemNameFld, 100.0);
		AnchorPane.setLeftAnchor(itemNameFld, 10.0);
		//itemNameFld.setFont(Font.font(12));
				
		TextArea itemPriceFld = new TextArea();
		itemPriceFld.setPrefSize(140, 20);
		AnchorPane.setTopAnchor(itemPriceFld, 100.0);
		AnchorPane.setLeftAnchor(itemPriceFld, 840.0);
				
		TextArea itemDescFld = new TextArea();
		itemDescFld.setPrefSize(970, 20);
		AnchorPane.setTopAnchor(itemDescFld, 160.0);
		AnchorPane.setLeftAnchor(itemDescFld, 10.0);
		
		Button buttonAddMenu = new Button( "ADD to\nMENU");
		buttonAddMenu.setPrefSize(80, 95);
		AnchorPane.setTopAnchor(buttonAddMenu, 100.0);
		AnchorPane.setLeftAnchor(buttonAddMenu, 990.0);
		
		// Button action
		buttonAddMenu.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				System.out.println( itemNameFld.getText() );
				Double tmpprice = Double.valueOf(itemPriceFld.getText());
				
				addItem( menu, itemNameFld.getText(), itemDescFld.getText(), tmpprice);
				
				listSave( menu );
				
				
				
				 
				menu.clear();														// Clears the menu LinkedList so that we can load the file and only the file.
				File file = new File("menu.txt");									// Loads the menu.txt file
				
				try (Scanner sc = new Scanner(file)) {
					sc.useDelimiter(",");												// Creates the breaks needed to parse the file
					
					int qtyItems = Integer.parseInt( sc.next() );							// Pulls out the quantity of Items in the file list
					//System.out.println( "Menu has " + qtyItems + " Items in the list." );	// TEST LINE
					
					for(int i = 0; i < qtyItems; i++) {								// Grabs name, desc, price at a time from the file.
						String itemName = sc.next();
						String itemDesc = sc.next();
						Double itemPrice = Double.parseDouble( sc.next() );

						Item a = new Item( itemName, itemDesc, itemPrice );			// Creates an Item
						menu.add(a);												// Add the Item to the LinkedList
						
					}// ENDS for
					sc.close();
				} catch (NumberFormatException e) {
					System.out.println("listImport try catch FAIL");
					e.printStackTrace();
				} catch (FileNotFoundException e1) {
					System.out.println("listImport2 try catch FAIL");
					e1.printStackTrace();
				}

				
				
				
				
				
				
				
				
				
				
				
				
				
				
			}// ENDS handle
		}); // ENDS setOnAction
		
		
		

		
		
		// *** FOR THE COUPON CREATE SIDE ***//
		// Static Objects
		
		Rectangle ccpRec = new Rectangle(1090, 10, 820, 60);
		ccpRec.setFill(Color.rgb(0, 102, 255));
		ccpRec.setStroke(Color.BLACK);
		
		Label ccpLbl = new Label("Coupon Creation");
		ccpLbl.setFont(Font.font(40));
		ccpLbl.setTextFill(Color.WHITE);
		AnchorPane.setTopAnchor(ccpLbl, 10.0);
		AnchorPane.setLeftAnchor(ccpLbl, 1360.0);
		
		Label ccDescLbl = new Label("Coupons are a great way to develop customer loyalty.\n"
				+ "Start here by offering your customers a percentage off after so many visits");
		//ccDescLbl.setFont(Font.font(40));
		//ccDescLbl.setTextFill(Color.WHITE);
		AnchorPane.setTopAnchor(ccDescLbl, 80.0);
		AnchorPane.setLeftAnchor(ccDescLbl, 1100.0);
		
		// Entry Box labels
		
		Label percent1Lbl = new Label("% off");
		percent1Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(percent1Lbl, 200.0);
		AnchorPane.setLeftAnchor(percent1Lbl, 1350.0);
		
		Label visit1Lbl = new Label("number of visits");
		visit1Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(visit1Lbl, 200.0);
		AnchorPane.setLeftAnchor(visit1Lbl, 1600.0);
		
		
		Label percent2Lbl = new Label("% off");
		percent2Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(percent2Lbl, 320.0);
		AnchorPane.setLeftAnchor(percent2Lbl, 1350.0);
		
		Label visit2Lbl = new Label("number of visits");
		visit2Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(visit2Lbl, 320.0);
		AnchorPane.setLeftAnchor(visit2Lbl, 1600.0);
		
		
		Label percent3Lbl = new Label("% off");
		percent3Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(percent3Lbl, 440.0);
		AnchorPane.setLeftAnchor(percent3Lbl, 1350.0);
		
		Label visit3Lbl = new Label("number of visits");
		visit3Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(visit3Lbl, 440.0);
		AnchorPane.setLeftAnchor(visit3Lbl, 1600.0);
		
		
		Label percent4Lbl = new Label("% off");
		percent4Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(percent4Lbl, 560.0);
		AnchorPane.setLeftAnchor(percent4Lbl, 1350.0);
		
		Label visit4Lbl = new Label("number of visits");
		visit4Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(visit4Lbl, 560.0);
		AnchorPane.setLeftAnchor(visit4Lbl, 1600.0);
		
		
		Label percent5Lbl = new Label("% off");
		percent5Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(percent5Lbl, 680.0);
		AnchorPane.setLeftAnchor(percent5Lbl, 1350.0);
		
		Label visit5Lbl = new Label("number of visits");
		visit5Lbl.setFont(Font.font(30));
		AnchorPane.setTopAnchor(visit5Lbl, 680.0);
		AnchorPane.setLeftAnchor(visit5Lbl, 1600.0);
		
		
		// Create Controls
		
		TextArea percent1Fld = new TextArea("5");
		percent1Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(percent1Fld, 180.00);
		AnchorPane.setLeftAnchor(percent1Fld, 1200.0);
		
		TextArea visit1Fld = new TextArea("5");
		visit1Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(visit1Fld, 180.0);
		AnchorPane.setLeftAnchor(visit1Fld, 1465.0);
		
		
		TextArea percent2Fld = new TextArea("10");
		percent2Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(percent2Fld, 300.0);
		AnchorPane.setLeftAnchor(percent2Fld, 1200.0);
		
		TextArea visit2Fld = new TextArea("10");
		visit2Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(visit2Fld, 300.0);
		AnchorPane.setLeftAnchor(visit2Fld, 1465.0);
		
		
		TextArea percent3Fld = new TextArea("12.5");
		percent3Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(percent3Fld, 420.0);
		AnchorPane.setLeftAnchor(percent3Fld, 1200.0);
		
		TextArea visit3Fld = new TextArea("15");
		visit3Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(visit3Fld, 420.0);
		AnchorPane.setLeftAnchor(visit3Fld, 1465.0);
		
		
		TextArea percent4Fld = new TextArea("15");
		percent4Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(percent4Fld, 540.0);
		AnchorPane.setLeftAnchor(percent4Fld, 1200.0);
		
		TextArea visit4Fld = new TextArea("9999");
		visit4Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(visit4Fld, 540.0);
		AnchorPane.setLeftAnchor(visit4Fld, 1465.0);
		
		
		TextArea percent5Fld = new TextArea("20");
		percent5Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(percent5Fld, 660.0);
		AnchorPane.setLeftAnchor(percent5Fld, 1200.0);
		
		TextArea visit5Fld = new TextArea("9999");
		visit5Fld.setPrefSize(100, 80);
		AnchorPane.setTopAnchor(visit5Fld, 660.0);
		AnchorPane.setLeftAnchor(visit5Fld, 1465.0);
		
		Button buttonSave = new Button( "Save");
		buttonSave.setPrefSize(200, 50);
		AnchorPane.setTopAnchor(buttonSave, 800.0);
		AnchorPane.setLeftAnchor(buttonSave, 1400.0);
		
		
		// *** Actual Menu ***
		
		int listLength = menu.size(); 					// Quantity of Items in the menu LinkedList
		//System.out.println( listLength );
		
		
	// One
		
		// Set visability
		Boolean item1Vis = false;			// Sets Visibility for One
		String name1 = "";
		String desc1 = "";
		Double price1 = 0.0;
		
		if( listLength > 0) { 
			name1 = menu.get(0).getName();
			desc1 = menu.get(0).getDesc();
			price1 = menu.get(0).getPrice();
			item1Vis = true;
		}
		
		Rectangle item1Rec = new Rectangle(10, 285, 970, 60);
		item1Rec.setFill(Color.TRANSPARENT);
		item1Rec.setStroke(Color.BLACK);
		item1Rec.setVisible( item1Vis );
		
		Label itemName1 = new Label( name1 );
		AnchorPane.setTopAnchor(itemName1, 290.0);
		AnchorPane.setLeftAnchor(itemName1, 20.0);
		itemName1.setVisible( item1Vis );
		
		Label itemDesc1 = new Label( desc1 );
		AnchorPane.setTopAnchor(itemDesc1, 315.0);
		AnchorPane.setLeftAnchor(itemDesc1, 20.0);
		itemDesc1.setVisible( item1Vis );
		
		Label itemPrice1 = new Label( String.format( "%.2f", price1 ) );
		AnchorPane.setTopAnchor(itemPrice1, 290.0);
		AnchorPane.setLeftAnchor(itemPrice1, 930.0);
		itemPrice1.setVisible( item1Vis );
		
		Button buttonItem1 = new Button( "REMOVE");
		buttonItem1.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem1, 285.0);
		AnchorPane.setLeftAnchor(buttonItem1, 990.0);
		buttonItem1.setVisible( item1Vis );
		
	// Two	
		Boolean item2Vis = false;
		String name2 = "";
		String desc2 = "";
		Double price2 = 0.0;
		
		if( listLength > 1) {
			name2 = menu.get(1).getName();
			desc2 = menu.get(1).getDesc();
			price2 = menu.get(1).getPrice();
			item2Vis = true;
		}
			
		Rectangle item2Rec = new Rectangle(10, 355, 970, 60);
		item2Rec.setFill(Color.TRANSPARENT);
		item2Rec.setStroke(Color.BLACK);
		item2Rec.setVisible( item2Vis );
		
		Label itemName2 = new Label( name2 );
		AnchorPane.setTopAnchor(itemName2, 360.0);
		AnchorPane.setLeftAnchor(itemName2, 20.0);
		itemName2.setVisible( item2Vis );
		
		Label itemDesc2 = new Label( desc2 );
		AnchorPane.setTopAnchor(itemDesc2, 385.0);
		AnchorPane.setLeftAnchor(itemDesc2, 20.0);
		itemDesc2.setVisible( item2Vis );
		
		Label itemPrice2 = new Label( String.format( "%.2f", price2 ));
		AnchorPane.setTopAnchor(itemPrice2, 360.0);
		AnchorPane.setLeftAnchor(itemPrice2, 930.0);
		itemPrice2.setVisible( item2Vis );
		
		Button buttonItem2 = new Button( "REMOVE");
		buttonItem2.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem2, 355.0);
		AnchorPane.setLeftAnchor(buttonItem2, 990.0);
		buttonItem2.setVisible( item2Vis );
		
	// Three
		Boolean item3Vis = false;
		String name3 = "";
		String desc3 = "";
		Double price3 = 0.0;
		
		if( listLength > 2) { 
			name3 = menu.get(2).getName();
			desc3 = menu.get(2).getDesc();
			price3 = menu.get(2).getPrice();
			item3Vis = true;
		}
		
		Rectangle item3Rec = new Rectangle(10, 425, 970, 60);
		item3Rec.setFill(Color.TRANSPARENT);
		item3Rec.setStroke(Color.BLACK);
		item3Rec.setVisible( item3Vis );
		
		Label itemName3 = new Label( name3 );
		AnchorPane.setTopAnchor(itemName3, 430.0);
		AnchorPane.setLeftAnchor(itemName3, 20.0);
		itemName3.setVisible( item3Vis );
		
		Label itemDesc3 = new Label( desc3 );
		AnchorPane.setTopAnchor(itemDesc3, 455.0);
		AnchorPane.setLeftAnchor(itemDesc3, 20.0);
		itemDesc3.setVisible( item3Vis );
		
		Label itemPrice3 = new Label( String.format( "%.2f", price3 ));
		AnchorPane.setTopAnchor(itemPrice3, 430.0);
		AnchorPane.setLeftAnchor(itemPrice3, 930.0);
		itemPrice3.setVisible( item3Vis );
		
		Button buttonItem3 = new Button( "REMOVE");
		buttonItem3.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem3, 425.0);
		AnchorPane.setLeftAnchor(buttonItem3, 990.0);
		buttonItem3.setVisible( item3Vis );	
		
	// Four
		Boolean item4Vis = false;
		String name4 = "";
		String desc4 = "";
		Double price4 = 0.0;
		
		if( listLength > 3) { 
			name4 = menu.get(3).getName();
			desc4 = menu.get(3).getDesc();
			price4 = menu.get(3).getPrice();
			item4Vis = true;
		}
		
		Rectangle item4Rec = new Rectangle(10, 495, 970, 60);
		item4Rec.setFill(Color.TRANSPARENT);
		item4Rec.setStroke(Color.BLACK);
		item4Rec.setVisible( item4Vis );
		
		Label itemName4 = new Label( name4 );
		AnchorPane.setTopAnchor(itemName4, 500.0);
		AnchorPane.setLeftAnchor(itemName4, 20.0);
		itemName4.setVisible( item4Vis );
		
		Label itemDesc4 = new Label( desc4 );
		AnchorPane.setTopAnchor(itemDesc4, 525.0);
		AnchorPane.setLeftAnchor(itemDesc4, 20.0);
		itemDesc4.setVisible( item4Vis );
		
		Label itemPrice4 = new Label( String.format( "%.2f", price4 ));
		AnchorPane.setTopAnchor(itemPrice4, 500.0);
		AnchorPane.setLeftAnchor(itemPrice4, 930.0);
		itemPrice4.setVisible( item4Vis );
		
		Button buttonItem4 = new Button( "REMOVE");
		buttonItem4.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem4, 495.0);
		AnchorPane.setLeftAnchor(buttonItem4, 990.0);
		buttonItem4.setVisible( item4Vis );
		
	// Five
		Boolean item5Vis = false;
		
		String name5 = "";
		String desc5 = "";
		Double price5 = 0.0;
		
		if( listLength > 4) { 
			name5 = menu.get(4).getName();
			desc5 = menu.get(4).getDesc();
			price5 = menu.get(4).getPrice();
			item5Vis = true;
		}
			
		Rectangle item5Rec = new Rectangle(10, 565, 970, 60);
		item5Rec.setFill(Color.TRANSPARENT);
		item5Rec.setStroke(Color.BLACK);
		item5Rec.setVisible( item5Vis );
			
		Label itemName5 = new Label( name5 );
		AnchorPane.setTopAnchor(itemName5, 570.0);
		AnchorPane.setLeftAnchor(itemName5, 20.0);
		itemName5.setVisible( item5Vis );
			
		Label itemDesc5 = new Label( desc5 );
		AnchorPane.setTopAnchor(itemDesc5, 595.0);
		AnchorPane.setLeftAnchor(itemDesc5, 20.0);
		itemDesc5.setVisible( item5Vis );
			
		Label itemPrice5 = new Label( String.format( "%.2f", price5 ));
		AnchorPane.setTopAnchor(itemPrice5, 570.0);
		AnchorPane.setLeftAnchor(itemPrice5, 930.0);
		itemPrice5.setVisible( item5Vis );
			
		Button buttonItem5 = new Button( "REMOVE");
		buttonItem5.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem5, 565.0);
		AnchorPane.setLeftAnchor(buttonItem5, 990.0);
		buttonItem5.setVisible( item5Vis );		
		
	// Six
		Boolean item6Vis = false;
		String name6 = "";
		String desc6 = "";
		Double price6 = 0.0;
		
		if( listLength > 5) { 
			name6 = menu.get(5).getName();
			desc6 = menu.get(5).getDesc();
			price6 = menu.get(5).getPrice();
			item6Vis = true;
		}
		
		Rectangle item6Rec = new Rectangle(10, 635, 970, 60);
		item6Rec.setFill(Color.TRANSPARENT);
		item6Rec.setStroke(Color.BLACK);
		item6Rec.setVisible( item6Vis );
		
		Label itemName6 = new Label( name6 );
		AnchorPane.setTopAnchor(itemName6, 640.0);
		AnchorPane.setLeftAnchor(itemName6, 20.0);
		itemName6.setVisible( item6Vis );
		
		Label itemDesc6 = new Label( desc6 );
		AnchorPane.setTopAnchor(itemDesc6, 665.0);
		AnchorPane.setLeftAnchor(itemDesc6, 20.0);
		itemDesc6.setVisible( item6Vis );
		
		Label itemPrice6 = new Label( String.format( "%.2f", price6 ));
		AnchorPane.setTopAnchor(itemPrice6, 640.0);
		AnchorPane.setLeftAnchor(itemPrice6, 930.0);
		itemPrice6.setVisible( item6Vis );
		
		Button buttonItem6 = new Button( "REMOVE");
		buttonItem6.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem6, 635.0);
		AnchorPane.setLeftAnchor(buttonItem6, 990.0);
		buttonItem6.setVisible( item6Vis );
		
	// Seven
		Boolean item7Vis = false;
		String name7 = "";
		String desc7 = "";
		Double price7 = 0.0;
		
		if( listLength > 6) { 
			name7 = menu.get(6).getName();
			desc7 = menu.get(6).getDesc();
			price7 = menu.get(6).getPrice();
			item7Vis = true;
		}
		
		Rectangle item7Rec = new Rectangle(10, 705, 970, 60);
		item7Rec.setFill(Color.TRANSPARENT);
		item7Rec.setStroke(Color.BLACK);
		item7Rec.setVisible( item7Vis );
		
		Label itemName7 = new Label( name7 );
		AnchorPane.setTopAnchor(itemName7, 710.0);
		AnchorPane.setLeftAnchor(itemName7, 20.0);
		itemName7.setVisible( item7Vis );
		
		Label itemDesc7 = new Label( desc7 );
		AnchorPane.setTopAnchor(itemDesc7, 735.0);
		AnchorPane.setLeftAnchor(itemDesc7, 20.0);
		itemDesc7.setVisible( item7Vis );
		
		Label itemPrice7 = new Label( String.format( "%.2f", price7 ));
		AnchorPane.setTopAnchor(itemPrice7, 710.0);
		AnchorPane.setLeftAnchor(itemPrice7, 930.0);
		itemPrice7.setVisible( item7Vis );
		
		Button buttonItem7 = new Button( "REMOVE");
		buttonItem7.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem7, 705.0);
		AnchorPane.setLeftAnchor(buttonItem7, 990.0);
		buttonItem7.setVisible( item7Vis );
		
	// Eight
		Boolean item8Vis = false;
		String name8 = "";
		String desc8 = "";
		Double price8 = 0.0;
		
		if( listLength > 7) { 
			name8 = menu.get(7).getName();
			desc8 = menu.get(7).getDesc();
			price8 = menu.get(7).getPrice();
			item8Vis = true;
		}
		
		Rectangle item8Rec = new Rectangle(10, 775, 970, 60);
		item8Rec.setFill(Color.TRANSPARENT);
		item8Rec.setStroke(Color.BLACK);
		item8Rec.setVisible( item8Vis );
		
		Label itemName8 = new Label( name8 );
		AnchorPane.setTopAnchor(itemName8, 780.0);
		AnchorPane.setLeftAnchor(itemName8, 20.0);
		itemName8.setVisible( item8Vis );
		
		Label itemDesc8 = new Label( desc8 );
		AnchorPane.setTopAnchor(itemDesc8, 805.0);
		AnchorPane.setLeftAnchor(itemDesc8, 20.0);
		itemDesc8.setVisible( item8Vis );
		
		Label itemPrice8 = new Label( String.format( "%.2f", price8 ));
		AnchorPane.setTopAnchor(itemPrice8, 780.0);
		AnchorPane.setLeftAnchor(itemPrice8, 930.0);
		itemPrice8.setVisible( item8Vis );
		
		Button buttonItem8 = new Button( "REMOVE");
		buttonItem8.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem8, 775.0);
		AnchorPane.setLeftAnchor(buttonItem8, 990.0);
		buttonItem8.setVisible( item8Vis );
		
	// Nine
		Boolean item9Vis = false;
		String name9 = "";
		String desc9 = "";
		Double price9 = 0.0;
		
		if( listLength > 8) {
			name9 = menu.get(8).getName();
			desc9 = menu.get(8).getDesc();
			price9 = menu.get(8).getPrice();
			item9Vis = true;
		}
		
		Rectangle item9Rec = new Rectangle(10, 845, 970, 60);
		item9Rec.setFill(Color.TRANSPARENT);
		item9Rec.setStroke(Color.BLACK);
		item9Rec.setVisible( item9Vis );
		
		Label itemName9 = new Label( name9 );
		AnchorPane.setTopAnchor(itemName9, 850.0);
		AnchorPane.setLeftAnchor(itemName9, 20.0);
		itemName9.setVisible( item9Vis );
		
		Label itemDesc9 = new Label( desc9 );
		AnchorPane.setTopAnchor(itemDesc9, 875.0);
		AnchorPane.setLeftAnchor(itemDesc9, 20.0);
		itemDesc9.setVisible( item9Vis );
		
		Label itemPrice9 = new Label( String.format( "%.2f", price9 ));
		AnchorPane.setTopAnchor(itemPrice9, 850.0);
		AnchorPane.setLeftAnchor(itemPrice9, 930.0);
		itemPrice9.setVisible( item9Vis );
		
		Button buttonItem9 = new Button( "REMOVE");
		buttonItem9.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem9, 845.0);
		AnchorPane.setLeftAnchor(buttonItem9, 990.0);
		buttonItem9.setVisible( item9Vis );	
		
	// Ten
		Boolean item10Vis = false;
		String name10 = "";
		String desc10 = "";
		Double price10 = 0.0;
		
		if( listLength > 9) { 
			name10 = menu.get(9).getName();
			desc10 = menu.get(9).getDesc();
			price10 = menu.get(9).getPrice();
			item10Vis = true;
		}
		
		Rectangle item10Rec = new Rectangle(10, 915, 970, 60);
		item10Rec.setFill(Color.TRANSPARENT);
		item10Rec.setStroke(Color.BLACK);
		item10Rec.setVisible( item10Vis );
		
		Label itemName10 = new Label( name10 );
		AnchorPane.setTopAnchor(itemName10, 920.0);
		AnchorPane.setLeftAnchor(itemName10, 20.0);
		itemName10.setVisible( item10Vis );
		
		Label itemDesc10 = new Label( desc10 );
		AnchorPane.setTopAnchor(itemDesc10, 945.0);
		AnchorPane.setLeftAnchor(itemDesc10, 20.0);
		itemDesc10.setVisible( item10Vis );
		
		Label itemPrice10 = new Label( String.format( "%.2f", price10 ));
		AnchorPane.setTopAnchor(itemPrice10, 920.0);
		AnchorPane.setLeftAnchor(itemPrice10, 930.0);
		itemPrice10.setVisible( item10Vis );
		
		Button buttonItem10 = new Button( "REMOVE");
		buttonItem10.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem10, 915.0);
		AnchorPane.setLeftAnchor(buttonItem10, 990.0);
		buttonItem10.setVisible( item10Vis );	
		
	// Eleven
		Boolean item11Vis = false;
		String name11 = "";
		String desc11 = "";
		Double price11 = 0.0;
		
		if( listLength > 10) { 
			name11 = menu.get(10).getName();
			desc11 = menu.get(10).getDesc();
			price11 = menu.get(10).getPrice();
			item11Vis = true;
		}
		
		Rectangle item11Rec = new Rectangle(10, 985, 970, 60);
		item11Rec.setFill(Color.TRANSPARENT);
		item11Rec.setStroke(Color.BLACK);
		item11Rec.setVisible( item11Vis );
		
		Label itemName11 = new Label( name11 );
		AnchorPane.setTopAnchor(itemName11, 990.0);
		AnchorPane.setLeftAnchor(itemName11, 20.0);
		itemName11.setVisible( item11Vis );
		
		Label itemDesc11 = new Label( desc11 );
		AnchorPane.setTopAnchor(itemDesc11, 115.0);
		AnchorPane.setLeftAnchor(itemDesc11, 20.0);
		itemDesc11.setVisible( item11Vis );
		
		Label itemPrice11 = new Label( String.format( "%.2f", price11 ));
		AnchorPane.setTopAnchor(itemPrice11, 990.0);
		AnchorPane.setLeftAnchor(itemPrice11, 930.0);
		itemPrice11.setVisible( item11Vis );
		
		Button buttonItem11 = new Button( "REMOVE");
		buttonItem11.setPrefSize(80, 60);
		AnchorPane.setTopAnchor(buttonItem11, 985.0);
		AnchorPane.setLeftAnchor(buttonItem11, 990.0);
		buttonItem11.setVisible( item11Vis );		

		
		
		
		
		
		root.getChildren().addAll( ccDescLbl, ccpRec, meRec, menuEditLbl, foodNameLbl, priceLbl, descLbl, 
				buttonAddMenu, mRec, menuLbl, itemNameFld, buttonSave,
				item1Rec, itemName1, itemPrice1, itemDesc1, buttonItem1,
				item2Rec, itemName2, itemPrice2, itemDesc2, buttonItem2,
				item3Rec, itemName3, itemPrice3, itemDesc3, buttonItem3,
				item4Rec, itemName4, itemPrice4, itemDesc4, buttonItem4,
				item5Rec, itemName5, itemPrice5, itemDesc5, buttonItem5,
				item6Rec, itemName6, itemPrice6, itemDesc6, buttonItem6,
				item7Rec, itemName7, itemPrice7, itemDesc7, buttonItem7,
				item8Rec, itemName8, itemPrice8, itemDesc8, buttonItem8,
				item9Rec, itemName9, itemPrice9, itemDesc9, buttonItem9,
				item10Rec, itemName10, itemPrice10, itemDesc10, buttonItem10,
				item11Rec, itemName11, itemPrice11, itemDesc11, buttonItem11,
				itemPriceFld, itemDescFld, ccpLbl,  
				percent1Lbl, percent1Fld, visit1Lbl, visit1Fld, 
				percent2Lbl, percent2Fld, visit2Lbl, visit2Fld, 
				percent3Lbl, percent3Fld, visit3Lbl, visit3Fld, 
				percent4Lbl, percent4Fld, visit4Lbl, visit4Fld, 
				percent5Lbl, percent5Fld, visit5Lbl, visit5Fld);
		
		
		
		
		Scene scene = new Scene(root, 1800, 900, Color.BEIGE);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	// Button Clicking handler
	//@Override
	//public void handle(ActionEvent event) {
		//if(event.getSource()==buttonAddMenu)
	//	System.out.println(event.getSource());
		
	//} // ENDS handle
	
	
	public static void main(String[] args) throws FileNotFoundException {

		launch(args);   // Runs the display thing.
		
		System.out.println("\n\nEND OF PROGRAM ");
		//scnr.close();
	}
		
	
	
	// Methods for the program**************************************************************

	//***** Reads in the first char (this is the quantity of Items in the list) 
	//      then builds the list by reading in the name, desc, price; creates an Item
	//      from them and adds them to the menu LinkedList.
	static void listImport( LinkedList<Item> menu) throws FileNotFoundException {
		
		menu.clear();														// Clears the menu LinkedList so that we can load the file and only the file.
		File file = new File("menu.txt");									// Loads the menu.txt file
		
		try (Scanner sc = new Scanner(file)) {
			sc.useDelimiter(",");												// Creates the breaks needed to parse the file
			
			int qtyItems = Integer.parseInt( sc.next() );							// Pulls out the quantity of Items in the file list
			//System.out.println( "Menu has " + qtyItems + " Items in the list." );	// TEST LINE
			
			for(int i = 0; i < qtyItems; i++) {								// Grabs name, desc, price at a time from the file.
				String itemName = sc.next();
				String itemDesc = sc.next();
				Double itemPrice = Double.parseDouble( sc.next() );

				Item a = new Item( itemName, itemDesc, itemPrice );			// Creates an Item
				menu.add(a);												// Add the Item to the LinkedList
				
			}// ENDS for
			sc.close();
		} 
		catch (NumberFormatException e) {
			System.out.println("listImport try catch FAIL");
			e.printStackTrace();
		}
		catch (FileNotFoundException e1) {
			System.out.println("listImport2 try catch FAIL");
			e1.printStackTrace();
		}

	}//ENDS listImport
	
	//***** Adds an item to the menu by prompting for the data, building an Item, and adding it to the list.
	static void addItem( LinkedList<Item> menu, String name, String desc, Double price ) {
		
		String itemName = name;
		String itemDesc = desc;
		Double itemPrice = price;
		
		Item a = new Item( itemName, itemDesc, itemPrice );
		menu.add(a);
		
	}
	
	//***** Saves the LinkedList by reading out each item of the list, separated by a comma. 
	static void listSave( LinkedList<Item> menu ) {
		
		PrintWriter writer;
		try {
			writer = new PrintWriter("menu.txt", "UTF-8");			// Initializes the writer and sets the file name
			writer.print( menu.size() + ",");							// Gives quantity of Items in the menu

			for(int i = 0; i < menu.size(); i++) {					// Gets name, desc, and price from each item in the menu
				
				writer.print(((Item) menu.get(i)).getName() + ",");
				writer.print(((Item) menu.get(i)).getDesc() + ",");
				writer.print(((Item) menu.get(i)).getPrice() + ",");
			}
			writer.close();											// Closes the txt file
		
		} catch (FileNotFoundException e) {
			System.out.println("SAVE FAILED");
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			System.out.println("SAVE FAILED TWO");
			e.printStackTrace();
		}
	}// ENDS listSave

	@Override
	public void handle(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}



} // ENDS Class
