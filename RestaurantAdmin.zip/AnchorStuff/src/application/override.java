package application;

public @interface override {

}
